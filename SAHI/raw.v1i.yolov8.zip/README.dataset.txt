# raw > 2024-10-14 12:20pm
https://universe.roboflow.com/demotenxun/raw-4kxy7

Provided by a Roboflow user
License: CC BY 4.0

